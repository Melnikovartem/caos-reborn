generator_text = """from caoslib.saving_tests import save_test
#save_test(data, ans)
from random import randint
"""
